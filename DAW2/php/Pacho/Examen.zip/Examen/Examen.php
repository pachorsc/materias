<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examen</title>
    <link rel="stylesheet" href="https://bootswatch.com/5/darkly/bootstrap.css">
    <link rel="stylesheet" href="./prueba.css">
</head>
<body>
    <?php
    //falta comprobar los espacis en blanco
    //se envia el form 1 y los pregmatch
    if (isset($_POST["for1"]) && !preg_match("'(?=.*[?|\/|.|/s]).*'" ,$_POST["nm"]) && !isset($_POST["for2"])) {
        $pre = explode("/",$_FILES["arch"]["type"]);
        //nombre
        if (!(is_dir($_POST["nm"]))) {
            mkdir($_POST["nm"]);
        }
        //tipo dentro de nombre
        if (!(is_dir("./".$_POST["nm"]."/".$pre[0]))) {
            mkdir("./".$_POST["nm"]."/".$pre[0]);
        }
        //guardar dentro de la carpeta de archivo dentro de la carpeta usuario
        move_uploaded_file($_FILES["arch"]["tmp_name"],"./".$_POST["nm"]."./".$pre[0]."/".$_FILES["arch"]["name"]);
        echo "<h1>Se ha guardado la imagen exitosamente en </h1>"."./".$_POST["nm"]."./".$pre[0]."/".$_FILES["arch"]["name"];
        
    } else if (isset($_POST["nm"]) && !isset($_POST["for2"])) {
        echo "<h1>Se ha escrito el nombre mal</h1>";
        echo " <h1>Formulario 1</h1><form action=\"#\" method=\"post\"  enctype=\"multipart/form-data\">
        <label for=\"nm\" class =\"form-label mt-4\">Nombre</label>
        <input type=\"text\" name=\"nm\" class=\"form-control\">
        <br>
        <label for=\"arch\" class =\"form-label mt-4\">Archivo</label>
        <input type=\"file\" name=\"arch\" class=\"form-control\">    
        <br>
        <input type=\"submit\" name=\"for1\" value=\"Enviar\" class=\"btn btn-primary\">    
    </form>";
    } else if(!isset($_POST["for2"])) {
        
        echo "<h1>Formulario 1</h1><form action=\"#\" method=\"post\"  enctype=\"multipart/form-data\">
        <label for=\"nm\" class =\"form-label mt-4\">Nombre</label>
        <input type=\"text\" name=\"nm\" class=\"form-control\">
        <br>
        <label for=\"arch\" class =\"form-label mt-4\">Archivo</label>
        <input type=\"file\" name=\"arch\" class=\"form-control\">    
        <br>
        <input type=\"submit\" name=\"for1\" value=\"Enviar\" class=\"btn btn-primary\">    
    </form>";
    }


    //si se ha enviado el formulario 2 y está lleno
    if (isset($_POST["for2"]) && isset($_POST["nm2"])) {
    if (isset($_POST["for2"]) && 
        preg_match("'^(?!.*[A-Z])(?!.*[^a-z])(?!.*[/s]).{3,15}$'",$_POST["nm2"]) &&
        preg_match("'(?=.*[0-9])(?=.*[-._,#%$@]).{8,16}'",$_POST["cont"]) &&
        preg_match("'^[^@]*@[^@]*[.][^@]*$'",$_POST["corr"])) {
            echo "<table>";
        foreach ($_POST as $key => $value) {
            
            if ($value=="Enviar") {
                
            } else if (!($key =="cont")) {
                echo "<tr>
                        <td>$key</td>
                        <td>$value</td>                
                      </tr>";
            } else {
                $cant = strlen($value);
                $contra = "";
                for ($i=0; $i < $cant; $i++) { 
                    $contra .= "*";
                }
                echo "<tr>
                        <td>$key</td>
                        <td>$contra</td>                
                      </tr>";
            }
        }
        echo "</table>";

            } else if (preg_match("'^(?!.*[A-Z])(?!.*[^a-z])(?!.*[/s]).{3,15}$'",$_POST["nm2"]) &&
                    preg_match("'(?=.*[0-9])(?=.*[-._,#%$@]).{8,16}'",$_POST["cont"]) &&
                    preg_match("'^[^@]*@[^@]*[.][^@]*$'",$_POST["corr"])) {
                        echo "<h1>Haz escrito un campo mal</h1>";
                echo "<h1>Formulario 2</h1><form action=\"#\" method=\"post\">
                        <label for=\"nm2\" class =\"form-label mt-4\">Nombre Usuario</label>
                        <input type=\"text\" name=\"nm2\" class=\"form-control\">
                        <br>
                        <label for=\"cont\" class =\"form-label mt-4\">Contraseña</label>
                        <input type=\"text\" name=\"cont\" class=\"form-control\">
                        <br>
                        <label for=\"corr\" class =\"form-label mt-4\">Correo</label>
                        <input type=\"text\" name=\"corr\" class=\"form-control\">
                        <br>
                        <input type=\"submit\" name=\"for2\" value=\"Enviar\" class=\"btn btn-primary\">
                    </form>";
            } 
        }else {
            echo "<h1>Formulario 2</h1><form action=\"#\" method=\"post\">
            <label for=\"nm2\" class =\"form-label mt-4\">Nombre Usuario</label>
            <input type=\"text\" name=\"nm2\" class=\"form-control\">
            <br>
            <label for=\"cont\" class =\"form-label mt-4\">Contraseña</label>
            <input type=\"text\" name=\"cont\" class=\"form-control\">
            <br>
            <label for=\"corr\" class =\"form-label mt-4\">Correo</label>
            <input type=\"text\" name=\"corr\" class=\"form-control\">
            <br>
            <input type=\"submit\" name=\"for2\" value=\"Enviar\" class=\"btn btn-primary\">
        </form>";
        }
    ?>

    
</body>
</html>